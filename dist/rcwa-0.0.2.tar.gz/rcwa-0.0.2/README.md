# rcwa
A S4 wrapper to make RCWA simulations with ease. 

## Installation 
pip install https://github.com/Luochenghuang/rcwa/raw/master/dist/rcwa-0.0.2.tar.gz
