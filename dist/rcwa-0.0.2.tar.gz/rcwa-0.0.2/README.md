# rcwa
A S4 wrapper to make RCWA simulations with ease. 
